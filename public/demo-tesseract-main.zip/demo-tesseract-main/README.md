# Code Demo

> `demo-*` are the repos I use for lessons 🌹.

You hopefully came here after watching the lesson ❤️. That said, feel free to play with this code even without watching the lesson 👏🏻 .

# More
Setup by

```
npm i
```

Now you can run this demo by executing:

```sh
npm run dev
```

And then visit http://localhost:3000
